package app;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.util.HashMap;
import java.util.Map;

public class OnlineShoppingSystem extends Application {
    private Map<String, String> users = new HashMap<>();
    private Map<Integer, String> products = new HashMap<>();
    private Map<Integer, Integer> cart = new HashMap<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Initialize sample data
        initializeUsers();
        initializeProducts();

        // Create GUI elements
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20));
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        Label usernameLabel = new Label("Username:");
        TextField usernameField = new TextField();
        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        Button loginButton = new Button("Login");

        gridPane.add(usernameLabel, 0, 0);
        gridPane.add(usernameField, 1, 0);
        gridPane.add(passwordLabel, 0, 1);
        gridPane.add(passwordField, 1, 1);
        gridPane.add(loginButton, 1, 2);

        // Login event handler
        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            if (validateLogin(username, password)) {
                showProductPage(primaryStage);
            } else {
                showAlert("Invalid credentials", "Please enter valid username and password.");
            }
        });

        // Set scene
        Scene scene = new Scene(gridPane, 300, 200);
        primaryStage.setTitle("Online Shopping System - Login");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void initializeUsers() {
        users.put("user1", "password1");
        users.put("user2", "password2");
    }

    private void initializeProducts() {
        products.put(1, "Laptop");
        products.put(2, "Smartphone");
        products.put(3, "Headphones");
    }

    private boolean validateLogin(String username, String password) {
        return users.containsKey(username) && users.get(username).equals(password);
    }

    private void showProductPage(Stage primaryStage) {
        // Create product browsing GUI
        GridPane productGrid = new GridPane();
        productGrid.setPadding(new Insets(20));
        productGrid.setHgap(10);
        productGrid.setVgap(10);

        int rowIndex = 0;
        for (Map.Entry<Integer, String> entry : products.entrySet()) {
            int productId = entry.getKey();
            String productName = entry.getValue();
            Label nameLabel = new Label(productName);
            Button addButton = new Button("Add to Cart");
            addButton.setOnAction(e -> addToCart(productId));
            productGrid.add(nameLabel, 0, rowIndex);
            productGrid.add(addButton, 1, rowIndex);
            rowIndex++;
        }

        Scene productScene = new Scene(productGrid, 400, 300);
        primaryStage.setScene(productScene);
        primaryStage.setTitle("Online Shopping System - Products");
        primaryStage.show();
    }

    private void addToCart(int productId) {
        cart.put(productId, cart.getOrDefault(productId, 0) + 1);
        showAlert("Item Added", "Product added to cart successfully.");
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
