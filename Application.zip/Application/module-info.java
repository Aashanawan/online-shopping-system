module Application {

    requires javafx.controls;
    requires javafx.fxml;

    requires javafx.graphics;
}